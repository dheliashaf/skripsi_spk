from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from apps.saham.models import Saham
from apps.sektor.models import Sektor
from apps.kriteria.models import Kriteria
from apps.analisis.services.normalization import NormalizationService
from apps.analisis.services.ranking import RankingService
import pandas as pd

def beranda(request):
    return render(request, 'landing/beranda.html', {'active': 'beranda'})

def data_saham(request):
    saham_list = Saham.objects.all().select_related('sektor')
    return render(request, 'landing/data_saham.html', {
        'saham_list': saham_list,
        'active': 'data_saham'
    })

def proses_analisis(request):
    saham_list = Saham.objects.all().select_related('sektor')
    sektor_list = Sektor.objects.all()

    # Proses jika user mengirim form (POST)
    if request.method == 'POST':
        # Ambil daftar id saham yang dipilih (max 3)
        saham_ids = request.POST.getlist('saham_ids')  # dari checkbox dengan name="saham_ids"
        if not saham_ids or len(saham_ids) < 2:
            messages.error(request, 'Pilih minimal 2 saham untuk dibandingkan.')
            return render(request, 'landing/proses_analisis.html', {
                'saham_list': saham_list,
                'sektor_list': sektor_list,
                'active': 'proses'
            })

        # Ambil data saham yang dipilih
        saham_terpilih = Saham.objects.filter(id__in=saham_ids).select_related('sektor')
        if saham_terpilih.count() < 2:
            messages.error(request, 'Pilih minimal 2 saham yang valid.')
            return render(request, 'landing/proses_analisis.html', {
                'saham_list': saham_list,
                'sektor_list': sektor_list,
                'active': 'proses'
            })

        # Ambil bobot kriteria
        bobot_dict = {k.kode: k.bobot for k in Kriteria.objects.all() if k.bobot > 0}
        if not bobot_dict:
            messages.error(request, 'Bobot kriteria belum dihitung oleh admin. Silakan coba lagi nanti.')
            return render(request, 'landing/proses_analisis.html', {
                'saham_list': saham_list,
                'sektor_list': sektor_list,
                'active': 'proses'
            })

        # Konversi ke DataFrame
        data = []
        for s in saham_terpilih:
            data.append({
                'kode_saham': s.kode_saham,
                'nama_perusahaan': s.nama_perusahaan,
                'sektor': s.sektor.nama if s.sektor else '',
                'periode': s.periode,
                'roe': s.roe,
                'eps': s.eps,
                'per': s.per,
                'der': s.der
            })
        df = pd.DataFrame(data)

        # Normalisasi Min-Max
        kriteria_sifat = {k.kode: k.sifat for k in Kriteria.objects.all()}
        df_normalized = df.copy()
        for col in ['roe', 'eps', 'per', 'der']:
            if col in df.columns:
                sifat = kriteria_sifat.get(col.upper(), 'BENEFIT')
                df_normalized[col] = NormalizationService.minmax_normalization(df[col], sifat)

        # Hitung skor SAW
        skor = RankingService.hitung_skor_akhir(df_normalized, bobot_dict)

        # Ranking
        df_ranked = RankingService.ranking_per_sektor(df_normalized, skor, 'sektor')

        # Siapkan hasil untuk ditampilkan
        hasil = []
        for idx, row in df_ranked.iterrows():
            # Tentukan rekomendasi berdasarkan skor
            skor_val = row['skor']
            if skor_val >= 0.8:
                rekom = 'BUY'
                rekom_color = 'success'
                rank_color = 'warning'
            elif skor_val >= 0.6:
                rekom = 'HOLD'
                rekom_color = 'warning'
                rank_color = 'secondary'
            else:
                rekom = 'SELL'
                rekom_color = 'danger'
                rank_color = 'secondary'

            hasil.append({
                'rank': int(row['rank']),
                'kode': row['kode_saham'],
                'nama': row['nama_perusahaan'],
                'skor': round(skor_val, 3),
                'rank_color': rank_color,
                'rekom': rekom,
                'rekom_color': rekom_color,
                'warna': 'success' if rekom == 'BUY' else 'warning' if rekom == 'HOLD' else 'danger',
                'persen': int(skor_val * 100)
            })

        # Simpan hasil ke session
        request.session['hasil_user'] = hasil

        # Redirect ke halaman hasil rekomendasi
        return redirect('hasil_rekomendasi')

    # GET request – tampilkan halaman
    return render(request, 'landing/proses_analisis.html', {
        'saham_list': saham_list,
        'sektor_list': sektor_list,
        'active': 'proses'
    })

def hasil_rekomendasi(request):
    # Ambil hasil dari session
    hasil = request.session.get('hasil_user', [])
    if not hasil:
        # Jika tidak ada, tampilkan pesan atau redirect
        messages.info(request, 'Silakan pilih saham terlebih dahulu di halaman Proses Analisis.')
        return redirect('proses_analisis')
    return render(request, 'landing/hasil_rekomendasi.html', {
        'hasil': hasil,
        'active': 'hasil'
    })

def tentang_metode(request):
    return render(request, 'landing/tentang_metode.html', {'active': 'tentang'})

def preview_pdf(request):
    return render(request, 'landing/preview_pdf.html', {'active': 'hasil'})